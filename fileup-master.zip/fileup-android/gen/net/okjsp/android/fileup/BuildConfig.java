/** Automatically generated file. DO NOT MODIFY */
package net.okjsp.android.fileup;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}